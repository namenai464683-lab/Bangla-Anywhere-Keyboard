Bangla Anywhere Keyboard — Offline Roman Bangla Preview Update

এই সংস্করণে দুইটি মোড আছে:

১) Roman → বাংলা
- ইংরেজি অক্ষরে Roman Bangla লিখুন (যেমন: ami valo achi)
- স্পেস চাপলে শব্দটি বাংলা অক্ষরে বদলে যাবে (আমি ভালো আছি)
- ইন্টারনেট ছাড়াই কাজ করবে।

২) বাংলা → Roman
- কিবোর্ডের বাংলা অক্ষর দিয়ে বাংলা লিখুন।
- কিবোর্ডের উপরের প্রিভিউ বারে Roman Bangla উচ্চারণ দেখাবে।
- উদাহরণ: তোমাদেরকে কেমনে ভুলবো → toderke kemone vulbo
- এই প্রিভিউও অফলাইনে কাজ করবে। এটি ইংরেজি অনুবাদ নয়; বাংলা কথার ইংরেজি অক্ষরে উচ্চারণ।

ইন্টারনেট:
- এই দুইটি transliteration সুবিধার জন্য ইন্টারনেট লাগে না।
- নেট থাকুক বা না থাকুক একইভাবে চলবে।
- Google Translate-এর মতো অর্থভিত্তিক অনুবাদ এই সংস্করণে নেই।

Android-এ চালু করার নিয়ম:
১) APK ইনস্টল করুন।
২) অ্যাপ খুলে Enable Keyboard চাপুন।
৩) তালিকা থেকে Bangla Anywhere Keyboard চালু করুন।
৪) Select Keyboard চাপুন এবং Bangla Anywhere Keyboard বেছে নিন।
৫) কিবোর্ডের উপরের মোড বাটনে চাপ দিয়ে Roman → বাংলা অথবা বাংলা → Roman নির্বাচন করুন।

APK build:
- GitHub repository-তে এই ZIP-এর ভেতরের BanglaAnywhereKeyboard ফোল্ডারের সব ফাইল আপলোড করুন।
- GitHub Actions > Build Android APK > Run workflow চালান।
- workflow শেষ হলে Artifacts থেকে Bangla-Anywhere-Keyboard-APK ডাউনলোড করুন।

নোট: এটি একটি প্রাথমিক অফলাইন phonetic transliteration ইঞ্জিন। সব বাংলা শব্দের Roman বানান অঞ্চল ও উচ্চারণভেদে আলাদা হতে পারে; সাধারণ শব্দের জন্য dictionary mapping এবং fallback ব্যবহার করা হয়েছে।

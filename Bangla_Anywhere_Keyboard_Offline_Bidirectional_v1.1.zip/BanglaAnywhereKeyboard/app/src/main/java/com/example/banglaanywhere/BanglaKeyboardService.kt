package com.example.banglaanywhere

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BanglaKeyboardService : InputMethodService() {
    private var romanToBangla = true
    private lateinit var root: LinearLayout
    private lateinit var preview: TextView
    private val rows = listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("z","x","c","v","b","n","m")
    )
    private val bnRows = listOf(
        listOf("ক","খ","গ","ঘ","চ","ছ","জ","ঝ","ট","ঠ"),
        listOf("ত","থ","দ","ধ","ন","প","ফ","ব","ভ"),
        listOf("ম","য","র","ল","শ","স","হ")
    )

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 8, 4, 8)
            setBackgroundColor(Color.rgb(20, 34, 30))
        }
        rebuild()
        return root
    }

    private fun rebuild() {
        root.removeAllViews()
        val top = LinearLayout(this)
        val toggle = key(if (romanToBangla) "Roman → বাংলা" else "বাংলা → Roman") {
            romanToBangla = !romanToBangla
            rebuild()
        }
        top.addView(toggle, LinearLayout.LayoutParams(0, 48, 1f))
        top.addView(key("⌫") { currentInputConnection?.deleteSurroundingText(1, 0); refreshPreview() },
            LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(top)
        preview = TextView(this).apply {
            text = "বাংলা লিখলে Roman Bangla এখানে দেখাবে"
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(8, 10, 8, 10)
            setBackgroundColor(Color.rgb(35, 48, 43))
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, 52))
        refreshPreview()
        val activeRows = if (romanToBangla) rows else bnRows
        activeRows.forEach { row ->
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER }
            row.forEach { label ->
                line.addView(key(label) { type(label) }, LinearLayout.LayoutParams(0, 49, 1f).apply {
                    setMargins(2, 3, 2, 3)
                })
            }
            root.addView(line)
        }
        val vowels = if (romanToBangla) listOf("a","i","u","e","o") else listOf("া","ি","ী","ু","ে","ো","্")
        val vowelRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        vowels.forEach { v -> vowelRow.addView(key(v) { type(v) }, LinearLayout.LayoutParams(0, 46, 1f).apply { setMargins(2,2,2,2) }) }
        root.addView(vowelRow)
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(key("?123") { type("?123") }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(key("স্পেস") { type(" ") }, LinearLayout.LayoutParams(0, 48, 3f))
        bottom.addView(key("↵") { currentInputConnection?.commitText("\n", 1) }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(bottom)
        root.addView(TextView(this).apply {
            text = if (romanToBangla) "ইংরেজি অক্ষরে লিখুন — স্পেস দিলে বাংলা হবে" else "বাংলা লিখুন — উপরে Roman উচ্চারণ দেখুন"
            setTextColor(Color.LTGRAY); textSize = 12f; gravity = Gravity.CENTER; setPadding(4,8,4,2)
        })
    }

    private fun key(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 16f; isAllCaps = false
        setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(43, 78, 64)))
        setPadding(0,0,0,0); setOnClickListener { action() }
    }

    private fun type(value: String) {
        if (value == "?123") return
        if (value == " ") {
            val ic = currentInputConnection ?: return
            if (romanToBangla) {
                val before = ic.getTextBeforeCursor(100, 0)?.toString().orEmpty()
                val word = before.takeLastWhile { !it.isWhitespace() }
                val converted = Transliterator.toBangla(word)
                if (word.isNotEmpty()) {
                    ic.deleteSurroundingText(word.length, 0)
                    ic.commitText(converted + " ", 1)
                } else ic.commitText(" ", 1)
            } else ic.commitText(" ", 1)
        } else currentInputConnection?.commitText(value, 1)
        refreshPreview()
    }

    private fun refreshPreview() {
        if (!::preview.isInitialized) return
        val before = currentInputConnection?.getTextBeforeCursor(300, 0)?.toString().orEmpty()
        val converted = if (romanToBangla) Transliterator.toBangla(before) else Transliterator.toRoman(before)
        preview.text = when {
            before.isBlank() -> if (romanToBangla) "Roman লিখুন — বাংলা সাজেশন দেখুন" else "বাংলা লিখুন — Roman উচ্চারণ দেখুন"
            else -> converted
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (::root.isInitialized) refreshPreview()
    }
}

package com.example.banglaanywhere

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
        }
        box.addView(TextView(this).apply {
            text = "বাংলা Anywhere Keyboard\n\n১) Enable Keyboard চাপুন।\n২) Bangla Anywhere Keyboard চালু করুন।\n৩) Select Keyboard চাপুন এবং এটি বেছে নিন।\n\nযেকোনো অ্যাপে টাইপ করার সময় 🌐 / কিবোর্ড আইকন থেকে কিবোর্ড বদলাতে পারবেন।"
            textSize = 18f
        })
        box.addView(Button(this).apply {
            text = "Enable Keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "Select Keyboard"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        setContentView(box)
    }
}

package com.example.banglaanywhere

/** Offline Bangla <-> Roman Bangla transliteration. No network/API required. */
object Transliterator {
    private val words = mapOf(
        "ami" to "আমি", "amra" to "আমরা", "amar" to "আমার", "amake" to "আমাকে",
        "tumi" to "তুমি", "tomar" to "তোমার", "tomake" to "তোমাকে", "tomader" to "তোমাদের",
        "tomaderke" to "তোমাদেরকে", "toderke" to "তোমাদেরকে", "toder" to "তোমাদের",
        "apni" to "আপনি", "apnar" to "আপনার", "apnake" to "আপনাকে",
        "ki" to "কি", "kno" to "কেন", "keno" to "কেন", "kemon" to "কেমন", "kemone" to "কেমনে",
        "acho" to "আছো", "achen" to "আছেন", "ase" to "আছে", "ache" to "আছে", "achi" to "আছি",
        "valo" to "ভালো", "bhalo" to "ভালো", "kharap" to "খারাপ", "bangla" to "বাংলা",
        "english" to "ইংলিশ", "likho" to "লিখো", "lekho" to "লেখো", "hoy" to "হয়", "hobe" to "হবে",
        "korbo" to "করবো", "koro" to "করো", "kore" to "করে", "kotha" to "কথা", "bujhi" to "বুঝি",
        "dhonnobad" to "ধন্যবাদ", "allah" to "আল্লাহ", "salam" to "সালাম", "assalamu" to "আসসালামু",
        "wa" to "ওয়া", "mobile" to "মোবাইল", "keyboard" to "কিবোর্ড", "phone" to "ফোন",
        "name" to "নাম", "na" to "না", "ha" to "হ্যাঁ", "hya" to "হ্যাঁ", "theke" to "থেকে",
        "jonno" to "জন্য", "ekhon" to "এখন", "aj" to "আজ", "kal" to "কাল", "din" to "দিন", "rat" to "রাত",
        "vulbo" to "ভুলবো", "bhulbo" to "ভুলবো"
    )

    private val tokens = listOf(
        "chh" to "ছ", "kh" to "খ", "gh" to "ঘ", "ch" to "চ", "jh" to "ঝ",
        "th" to "থ", "dh" to "ধ", "ph" to "ফ", "bh" to "ভ", "sh" to "শ",
        "ng" to "ঙ", "ny" to "ঞ", "tt" to "ট্ট", "dd" to "ড্ড",
        "k" to "ক", "g" to "গ", "c" to "ক", "j" to "জ", "t" to "ত", "d" to "দ",
        "n" to "ন", "p" to "প", "f" to "ফ", "b" to "ব", "v" to "ভ", "m" to "ম",
        "r" to "র", "l" to "ল", "s" to "স", "h" to "হ", "y" to "য়", "w" to "ও",
        "z" to "জ", "q" to "ক", "x" to "ক্স"
    ).sortedByDescending { it.first.length }

    fun toBangla(input: String): String {
        val s = input.lowercase().trim()
        if (s.isEmpty()) return input
        words[s]?.let { return it }
        return Regex("\\s+|[^\\s]+").findAll(s).joinToString("") { match ->
            val part = match.value
            if (part.isBlank()) part else words[part] ?: convertRomanWord(part)
        }
    }

    private fun convertRomanWord(s: String): String {
        val out = StringBuilder(); var i = 0
        while (i < s.length) {
            val vowel = vowelAt(s, i)
            if (vowel != null) { out.append(vowel.first); i += vowel.second; continue }
            val token = tokens.firstOrNull { s.startsWith(it.first, i) }
            if (token != null) { out.append(token.second); i += token.first.length }
            else { out.append(s[i]); i++ }
        }
        return out.toString()
    }

    private fun vowelAt(s: String, i: Int): Pair<String, Int>? {
        val vowels = listOf("aa" to "আ", "ee" to "ঈ", "ii" to "ঈ", "oo" to "ঊ", "oi" to "ঐ", "ou" to "ঔ", "ai" to "ঐ", "a" to "আ", "i" to "ই", "u" to "উ", "e" to "এ", "o" to "ও")
        return vowels.firstOrNull { s.startsWith(it.first, i) }
    }

    private val romanWords = mapOf(
        "তোমাদেরকে" to "toderke", "তোমাদের" to "tomader", "তোমাকে" to "tomake", "তোমার" to "tomar",
        "কেমনে" to "kemone", "কেমন" to "kemon", "ভুলবো" to "vulbo", "ভুলব" to "vulbo",
        "আমি" to "ami", "আমরা" to "amra", "আমার" to "amar", "আমাকে" to "amake",
        "তুমি" to "tumi", "আপনি" to "apni", "আপনার" to "apnar", "কি" to "ki", "কেন" to "keno",
        "আছো" to "acho", "আছেন" to "achen", "আছে" to "ache", "আছি" to "achi",
        "ভালো" to "valo", "খারাপ" to "kharap", "বাংলা" to "bangla", "ইংলিশ" to "english",
        "হয়" to "hoy", "হবে" to "hobe", "করবো" to "korbo", "করো" to "koro", "করে" to "kore",
        "কথা" to "kotha", "বুঝি" to "bujhi", "ধন্যবাদ" to "dhonnobad", "আল্লাহ" to "allah",
        "থেকে" to "theke", "জন্য" to "jonno", "এখন" to "ekhon", "আজ" to "aj", "কাল" to "kal",
        "দিন" to "din", "রাত" to "rat", "না" to "na", "হ্যাঁ" to "hya", "নাম" to "nam"
    )

    /** Produces readable Roman Bangla, e.g. তোমাদেরকে কেমনে ভুলবো -> toderke kemone vulbo. */
    fun toRoman(input: String): String {
        return Regex("\\s+|[^\\s]+").findAll(input).joinToString("") { match ->
            val part = match.value
            if (part.isBlank()) part else romanWords[part] ?: romanizeCharacters(part)
        }
    }

    private val romanChars = mapOf(
        'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh", 'চ' to "ch", 'ছ' to "chh",
        'জ' to "j", 'ঝ' to "jh", 'ট' to "t", 'ঠ' to "th", 'ত' to "t", 'থ' to "th",
        'দ' to "d", 'ধ' to "dh", 'ন' to "n", 'প' to "p", 'ফ' to "f", 'ব' to "b",
        'ভ' to "v", 'ম' to "m", 'য' to "j", 'র' to "r", 'ল' to "l", 'শ' to "sh",
        'ষ' to "sh", 'স' to "s", 'হ' to "h", 'ড়' to "r", 'ঢ়' to "rh", 'য়' to "y",
        'ং' to "ng", 'ঃ' to "h", 'ঁ' to "n"
    )
    private fun romanizeCharacters(s: String): String = buildString {
        s.forEach { c -> append(romanChars[c] ?: when (c) {
            'অ' -> "o"; 'আ' -> "a"; 'ই','ঈ' -> "i"; 'উ','ঊ' -> "u"; 'এ' -> "e"
            'ঐ' -> "oi"; 'ও' -> "o"; 'ঔ' -> "ou"; 'া' -> "a"; 'ি','ী' -> "i"
            'ু','ূ' -> "u"; 'ৃ' -> "ri"; 'ে' -> "e"; 'ৈ' -> "oi"; 'ো' -> "o"
            'ৌ' -> "ou"; '্' -> ""; '।' -> "."; else -> c.toString()
        }) }
    }
}
